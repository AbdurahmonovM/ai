#!/bin/bash
set -e

# Auto-set WEB_APP_URL from Replit dev domain if not already set
if [ -z "$WEB_APP_URL" ] && [ -n "$REPLIT_DEV_DOMAIN" ]; then
    export WEB_APP_URL="https://$REPLIT_DEV_DOMAIN"
fi

echo "================================================"
echo " Hisobchi AI — starting up"
echo "================================================"
echo "WEB_APP_URL : ${WEB_APP_URL:-<not set>}"
echo "BOT_MODE    : ${BOT_MODE:-polling}"
echo "AI_PROVIDER : ${AI_PROVIDER:-groq}"
echo "================================================"

# Validate required secrets before trying to start anything
MISSING=""
if [ -z "$BOT_TOKEN" ]; then
    MISSING="$MISSING BOT_TOKEN"
fi
if [ -z "$GROQ_API_KEY" ] && [ "${AI_PROVIDER:-groq}" = "groq" ]; then
    MISSING="$MISSING GROQ_API_KEY"
fi
if [ -z "$OPENAI_API_KEY" ] && [ "${AI_PROVIDER}" = "openai" ]; then
    MISSING="$MISSING OPENAI_API_KEY"
fi

if [ -n "$MISSING" ]; then
    echo ""
    echo "ERROR: The following required environment variables are not set:"
    for var in $MISSING; do
        echo "  - $var"
    done
    echo ""
    echo "Please add them in Replit Secrets (padlock icon) or Railway Variables."
    echo ""
    echo "Starting web server only (bot disabled until secrets are provided)..."
    echo ""
    # Start web server only so the preview pane works
    exec uvicorn web_app_server:app --host 0.0.0.0 --port 5000
fi

# All secrets present — start web server + bot in parallel
uvicorn web_app_server:app --host 0.0.0.0 --port 5000 &
WEB_PID=$!

python bot.py &
BOT_PID=$!

echo "Web server PID: $WEB_PID"
echo "Bot PID       : $BOT_PID"

# If either process dies, kill the other and exit
wait -n $WEB_PID $BOT_PID
EXIT_CODE=$?
kill $WEB_PID $BOT_PID 2>/dev/null || true
exit $EXIT_CODE
