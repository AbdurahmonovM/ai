"""
config.py
=========
Centralised, type-safe application configuration.

All secrets and environment-specific values live in a `.env` file (see
`.env.example`) and are loaded here exactly once via a cached singleton.
Import `settings` anywhere in the project:

    from config import settings
    print(settings.BOT_TOKEN)
"""

import os
from functools import lru_cache
from typing import Literal
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _default_web_app_url() -> str:
    """
    Auto-detect the public URL in common hosting environments so the operator
    doesn't have to set WEB_APP_URL manually on a first deploy.

    Priority:
      1. WEB_APP_URL env var (explicit, always wins)
      2. RAILWAY_PUBLIC_DOMAIN  — Railway injects this automatically
      3. REPLIT_DEV_DOMAIN      — Replit dev preview
      4. Empty string           — will be caught by check_bot_ready()
    """
    if os.environ.get("WEB_APP_URL"):
        return os.environ["WEB_APP_URL"]
    if os.environ.get("RAILWAY_PUBLIC_DOMAIN"):
        domain = os.environ["RAILWAY_PUBLIC_DOMAIN"].rstrip("/")
        if not domain.startswith("http"):
            domain = f"https://{domain}"
        return domain
    if os.environ.get("REPLIT_DEV_DOMAIN"):
        return f"https://{os.environ['REPLIT_DEV_DOMAIN']}"
    return ""


class Settings(BaseSettings):
    """Strongly-typed application settings, validated at startup."""

    # --- Telegram ---
    BOT_TOKEN: str = Field(default="", description="Token from @BotFather")
    # Public HTTPS URL where the Web App is served (required by Telegram).
    # On Railway this is your service domain, e.g.
    #   https://hisobchi-production.up.railway.app
    # Auto-detected from RAILWAY_PUBLIC_DOMAIN if not set explicitly.
    WEB_APP_URL: str = Field(
        default_factory=_default_web_app_url,
        description="Public HTTPS base URL of the Web App",
    )

    # Secret shared with Telegram so we can verify incoming webhook requests
    # (sent back by Telegram in the X-Telegram-Bot-Api-Secret-Token header).
    WEBHOOK_SECRET: str = Field(
        default="change-me-please", description="Random secret for webhook verification"
    )
    # Set to "webhook" on Railway (single web process) or "polling" for local dev.
    BOT_MODE: Literal["webhook", "polling"] = "polling"

    # --- AI provider (STT + NLP) ---
    # "groq"   -> FREE: Groq Whisper + Llama (one key from console.groq.com)
    # "openai" -> paid: OpenAI Whisper + GPT-4o-mini
    AI_PROVIDER: Literal["groq", "openai"] = "groq"

    # Provide the key for whichever provider you chose. The other can stay empty.
    GROQ_API_KEY: str = Field(default="", description="Free key from console.groq.com")
    OPENAI_API_KEY: str = Field(default="", description="OpenAI API key (paid)")

    # Optional model overrides. If left empty, sensible per-provider defaults are
    # picked by the `whisper_model` / `nlp_model` properties below.
    WHISPER_MODEL: str = ""
    NLP_MODEL: str = ""

    # --- Database ---
    # Dev default: local async SQLite file. Prod example:
    #   postgresql+asyncpg://user:pass@host:5432/hisobchi
    DATABASE_URL: str = "sqlite+aiosqlite:///./hisobchi.db"

    # --- Server ---
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # --- Behaviour ---
    DEFAULT_CURRENCY: str = "UZS"
    LOG_LEVEL: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    @field_validator("DATABASE_URL")
    @classmethod
    def _normalize_db_url(cls, v: str) -> str:
        """Make Railway's / Replit's Postgres URL compatible with asyncpg.

        1. Rewrite postgres:// / postgresql:// -> postgresql+asyncpg://
        2. Strip ?sslmode=... — asyncpg does not accept it as a query param.
           SSL is enabled via connect_args in database.py instead.
        """
        if v.startswith("postgres://"):
            v = v.replace("postgres://", "postgresql+asyncpg://", 1)
        elif v.startswith("postgresql://"):
            v = v.replace("postgresql://", "postgresql+asyncpg://", 1)

        if v.startswith("postgresql+asyncpg://"):
            parsed = urlparse(v)
            params = parse_qs(parsed.query, keep_blank_values=True)
            params.pop("sslmode", None)
            new_query = urlencode({k: vals[0] for k, vals in params.items()})
            v = urlunparse(parsed._replace(query=new_query))

        return v

    def check_bot_ready(self) -> list[str]:
        """Return a list of missing required secrets (empty = all good)."""
        missing = []
        if not self.BOT_TOKEN:
            missing.append("BOT_TOKEN")
        if not self.WEB_APP_URL:
            missing.append("WEB_APP_URL")
        if self.AI_PROVIDER == "groq" and not self.GROQ_API_KEY:
            missing.append("GROQ_API_KEY")
        if self.AI_PROVIDER == "openai" and not self.OPENAI_API_KEY:
            missing.append("OPENAI_API_KEY")
        return missing

    # --- AI provider resolution (used by speech_service & nlp_service) ---
    @property
    def ai_api_key(self) -> str:
        """API key for the active provider."""
        return self.GROQ_API_KEY if self.AI_PROVIDER == "groq" else self.OPENAI_API_KEY

    @property
    def ai_base_url(self) -> str | None:
        """Base URL for the active provider (Groq is OpenAI-API-compatible)."""
        # None lets the OpenAI SDK use its own default endpoint.
        return "https://api.groq.com/openai/v1" if self.AI_PROVIDER == "groq" else None

    @property
    def whisper_model(self) -> str:
        """STT model name — explicit override or per-provider default."""
        if self.WHISPER_MODEL:
            return self.WHISPER_MODEL
        return "whisper-large-v3-turbo" if self.AI_PROVIDER == "groq" else "whisper-1"

    @property
    def nlp_model(self) -> str:
        """NLP model name — explicit override or per-provider default."""
        if self.NLP_MODEL:
            return self.NLP_MODEL
        return "llama-3.3-70b-versatile" if self.AI_PROVIDER == "groq" else "gpt-4o-mini"

    @property
    def webhook_path(self) -> str:
        """URL path Telegram will POST updates to (kept secret-ish)."""
        return f"/webhook/{self.WEBHOOK_SECRET}"

    @property
    def webhook_url(self) -> str:
        """Absolute webhook URL registered with Telegram via setWebhook."""
        return f"{self.WEB_APP_URL.rstrip('/')}{self.webhook_path}"


@lru_cache
def get_settings() -> Settings:
    """Return a cached Settings instance (parsed only once per process)."""
    return Settings()  # type: ignore[call-arg]


# Convenience module-level singleton.
settings = get_settings()
